import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "AlbumServlet", value = "/albums")
@MultipartConfig
public class AlbumServlet extends HttpServlet  {
    // Fixed album key for POST responses
    private static final String FIXED_ALBUM_ID = "album123";

    // Gson instance for JSON serialization/deserialization
    private static final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        AlbumInfo albumInfo = new AlbumInfo(
                "Sex Pistols",
                "Never Mind The Bollocks!",
                "1977"
        );
        sendResponse(response, HttpServletResponse.SC_OK, albumInfo);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Validate content type - must be multipart/form-data for file uploads
        if (!request.getContentType().startsWith("multipart/form-data")) {
            sendResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                    new ErrorMsg("Content-Type must be multipart/form-data"));
            return;
        }

        try {
            Part imagePart = request.getPart("image");
            if (imagePart == null) {
                sendResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                        new ErrorMsg("Image is required"));
                return;
            }

            // Return fixed album ID and actual image size
            sendResponse(response, HttpServletResponse.SC_OK,
                    new ImageMetaData(FIXED_ALBUM_ID, String.valueOf(imagePart.getSize())));
        } catch (Exception e) {
            sendResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                    new ErrorMsg("Invalid request: " + e.getMessage()));
        }
    }

    /**
     * Helper method to send JSON responses.
     * Sets the content type, status code, and converts the response object to JSON.
     *
     * @param response The HTTP response object
     * @param status The HTTP status code
     * @param data The object to be converted to JSON and sent in the response
     */
    private void sendResponse(HttpServletResponse response, int status, Object data)
            throws IOException {
        response.setContentType("application/json");
        response.setStatus(status);
        PrintWriter out = response.getWriter();
        out.print(gson.toJson(data));
        out.flush();
    }
}

class AlbumInfo {
    private final String artist;
    private final String title;
    private final String year;

    AlbumInfo(String artist, String title, String year) {
        this.artist = artist;
        this.title = title;
        this.year = year;
    }

    String getArtist() { return artist; }
    String getTitle() { return title; }
    String getYear() { return year; }
}

class ImageMetaData {
    private final String albumID;
    private final String imageSize;

    ImageMetaData(String albumID, String imageSize) {
        this.albumID = albumID;
        this.imageSize = imageSize;
    }
}

class ErrorMsg {
    private final String msg;

    ErrorMsg(String msg) {
        this.msg = msg;
    }
}
