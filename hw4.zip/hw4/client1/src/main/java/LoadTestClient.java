import java.io.*;
import java.net.*;
import java.net.http.*;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.*;

public class LoadTestClient {

  private static final int MAX_RETRIES = 5;
  private static final int POST_GET_COUNT = 1000;

  public static void main(String[] args) throws Exception {
    if (args.length != 4) {
      System.out.println("Usage: java LoadTestClient <threadGroupSize> <numThreadGroups> <delay> <IPAddr>");
      return;
    }

    int threadGroupSize = Integer.parseInt(args[0]);
    int numThreadGroups = Integer.parseInt(args[1]);
    int delay = Integer.parseInt(args[2]);
    String serverUrl = args[3];

    // Initialize HttpClient
    HttpClient client = HttpClient.newHttpClient();

    // Take timestamp before starting the load testing
    long startTime = System.currentTimeMillis();

    // Initialize threads for the test
    ExecutorService executor = Executors.newFixedThreadPool(threadGroupSize * numThreadGroups);

    // Phase 1: Initialize 10 threads that make 100 POST/GET requests
    for (int i = 0; i < 10; i++) {
      executor.submit(() -> {
        try {
          // Initialize: POST and GET 100 times
          for (int j = 0; j < 100; j++) {
            sendPostRequest(client, serverUrl);
            sendGetRequest(client, serverUrl + "/1");
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
      });
    }

    // Wait for initialization to complete
    executor.shutdown();
    executor.awaitTermination(1, TimeUnit.MINUTES);

    // Phase 2: Load testing with multiple thread groups
    for (int group = 0; group < numThreadGroups; group++) {
      // Wait for delay seconds before starting the next group
      Thread.sleep(delay * 1000);

      // Start new thread group
      executor = Executors.newFixedThreadPool(threadGroupSize);
      for (int i = 0; i < threadGroupSize; i++) {
        executor.submit(() -> {
          try {
            // Perform POST and GET 1000 times each
            for (int j = 0; j < POST_GET_COUNT; j++) {
              sendPostRequest(client, serverUrl);
              sendGetRequest(client, serverUrl + "/1");
            }
          } catch (Exception e) {
            e.printStackTrace();
          }
        });
      }

      // Wait for the thread group to finish
      executor.shutdown();
      executor.awaitTermination(1, TimeUnit.MINUTES);
    }

    // Take timestamp after load testing
    long endTime = System.currentTimeMillis();
    long wallTime = (endTime - startTime) / 1000;

    // Output the results
    System.out.println("Wall Time: " + wallTime + " seconds");
    // You can modify this to calculate throughput based on the number of requests made
    System.out.println("Throughput: " + (POST_GET_COUNT * numThreadGroups * threadGroupSize) / wallTime + " requests per second");
  }

  // Helper method to send a POST request with the local image and profile data
  private static void sendPostRequest(HttpClient client, String serverUrl) throws IOException, InterruptedException {
    String imagePath = "C:/Users/seren/Desktop/hw4a/client1/src/main/java/example.jpg";
    String profileData = "{ \"title\": \"Never Mind The Bollocks!\", \"year\": \"1979\", \"artist\": \"Sex Pistolssss\" }";

    byte[] imageBytes = Files.readAllBytes(Path.of(imagePath));
    String boundary = "----JavaMultipartBoundary" + System.currentTimeMillis();
    String lineBreak = "\r\n";

    String requestBody =
        "--" + boundary + lineBreak +
            "Content-Disposition: form-data; name=\"image\"; filename=\"example.jpg\"" + lineBreak +
            "Content-Type: image/jpeg" + lineBreak + lineBreak +
            new String(imageBytes) + lineBreak +
            "--" + boundary + lineBreak +
            "Content-Disposition: form-data; name=\"profile\"" + lineBreak + lineBreak +
            profileData + lineBreak +
            "--" + boundary + "--" + lineBreak;

    HttpRequest request = HttpRequest.newBuilder()
        .uri(URI.create(serverUrl))
        .header("Content-Type", "multipart/form-data; boundary=" + boundary)
        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
        .build();

    HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

    if (response.statusCode() != 200) {
      retryRequest(client, serverUrl);
    }
  }

  // Helper method to send a GET request
  private static void sendGetRequest(HttpClient client, String serverUrl) throws IOException, InterruptedException {
    HttpRequest request = HttpRequest.newBuilder()
        .uri(URI.create(serverUrl))
        .GET()
        .build();

    HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

    if (response.statusCode() != 200) {
      retryRequest(client, serverUrl);
    }
  }

  // Retry logic for failed requests
  private static void retryRequest(HttpClient client, String serverUrl) throws InterruptedException, IOException {
    int retries = 0;
    boolean success = false;

    while (retries < MAX_RETRIES && !success) {
      HttpRequest request = HttpRequest.newBuilder()
          .uri(URI.create(serverUrl))
          .POST(HttpRequest.BodyPublishers.noBody())
          .build();

      HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
      if (response.statusCode() == 200) {
        success = true;
      } else {
        retries++;
        Thread.sleep(1000);  // Wait for 1 second before retrying
      }
    }

    if (!success) {
      System.out.println("Request failed after " + MAX_RETRIES + " retries.");
    }
  }
}
