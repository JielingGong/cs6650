import java.io.*;
import java.net.http.*;
import java.net.http.HttpResponse.BodyHandlers;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;

public class SimplePostTest {
  public static void main(String[] args) throws Exception {
    String serverUrl = "http://3.91.196.197:8080/IGORTON/AlbumStore/1.0.0/albums";
    String imagePath = "C:/Users/seren/Desktop/hw4a/client1/src/main/java/example.jpg";
    String profileData = "{ \"title\": \"Never Mind The Bollocks!\", \"year\": \"1979\", \"artist\": \"Sex Pistolssss\" }";

    sendPostRequest(serverUrl, imagePath, profileData);
  }

  private static void sendPostRequest(String serverUrl, String imagePath, String profileData) throws IOException, InterruptedException {
    HttpClient client = HttpClient.newHttpClient();

    // 读取本地图片
    byte[] imageBytes = Files.readAllBytes(Path.of(imagePath));

    // 构造 multipart/form-data 请求体
    String boundary = "----JavaMultipartBoundary" + System.currentTimeMillis();
    String lineBreak = "\r\n";

    String requestBody =
        "--" + boundary + lineBreak +
            "Content-Disposition: form-data; name=\"image\"; filename=\"example.jpg\"" + lineBreak +
            "Content-Type: image/jpeg" + lineBreak + lineBreak +
            new String(imageBytes) + lineBreak +
            "--" + boundary + lineBreak +
            "Content-Disposition: form-data; name=\"profile\"" + lineBreak + lineBreak +
            profileData + lineBreak +
            "--" + boundary + "--" + lineBreak;

    HttpRequest request = HttpRequest.newBuilder()
        .uri(URI.create(serverUrl))
        .header("Content-Type", "multipart/form-data; boundary=" + boundary)
        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
        .build();

    HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

    // 输出 API 响应状态码和错误信息
    System.out.println("Response Code: " + response.statusCode());
    System.out.println("Response Body: " + response.body());
  }
}

