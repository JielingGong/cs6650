/**
 * This is a simple client to test the connection to the server.
 */
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class SimpleHttpClient {
  public static void main(String[] args) throws Exception {
    // aws go-server
    String serverUri = "http://54.89.140.32:8080/IGORTON/AlbumStore/1.0.0/albums/1";

    HttpClient client = HttpClient.newHttpClient();

    HttpRequest request = HttpRequest.newBuilder()
        .uri(new URI(serverUri))
        .GET()
        .build();

    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

    System.out.println("Response Code: " + response.statusCode());
    System.out.println("Response Body: " + response.body());
  }
}
