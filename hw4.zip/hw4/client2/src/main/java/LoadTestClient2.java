import java.io.*;
import java.net.*;
import java.net.http.*;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class LoadTestClient2 {
  private static final int MAX_RETRIES = 5;
  private static final int POST_GET_COUNT = 1000;
  private static final List<Long> postLatencies = new ArrayList<>();
  private static final List<Long> getLatencies = new ArrayList<>();
  private static final String CSV_FILE = "latency_results.csv";

  public static void main(String[] args) throws Exception {
    if (args.length != 4) {
      System.out.println("Usage: java LoadTestClient <threadGroupSize> <numThreadGroups> <delay> <IPAddr>");
      return;
    }

    int threadGroupSize = Integer.parseInt(args[0]);
    int numThreadGroups = Integer.parseInt(args[1]);
    int delay = Integer.parseInt(args[2]);
    String serverUrl = args[3];

    HttpClient client = HttpClient.newHttpClient();
    long startTime = System.currentTimeMillis();
    ExecutorService executor = Executors.newFixedThreadPool(threadGroupSize * numThreadGroups);

    for (int group = 0; group < numThreadGroups; group++) {
      Thread.sleep(delay * 1000);
      for (int i = 0; i < threadGroupSize; i++) {
        executor.submit(() -> {
          try {
            for (int j = 0; j < POST_GET_COUNT; j++) {
              sendPostRequest(client, serverUrl);
              sendGetRequest(client, serverUrl + "/1");
            }
          } catch (Exception e) {
            e.printStackTrace();
          }
        });
      }
    }

    executor.shutdown();
    executor.awaitTermination(1, TimeUnit.HOURS);

    long endTime = System.currentTimeMillis();
    long wallTime = (endTime - startTime) / 1000;

    System.out.println("Wall Time: " + wallTime + " seconds");
    System.out.println("Throughput: " + (POST_GET_COUNT * numThreadGroups * threadGroupSize) / wallTime + " requests per second");
    computeStatistics();
  }

  private static void sendPostRequest(HttpClient client, String serverUrl) throws IOException, InterruptedException {
    String imagePath = "C:/Users/seren/Desktop/hw4a/client1/src/main/java/example.jpg";
    String profileData = "{ \"title\": \"Never Mind The Bollocks!\", \"year\": \"1979\", \"artist\": \"Sex Pistols\" }";

    byte[] imageBytes = Files.readAllBytes(Path.of(imagePath));
    String boundary = "----JavaMultipartBoundary" + System.currentTimeMillis();
    String lineBreak = "\r\n";

    String requestBody =
        "--" + boundary + lineBreak +
            "Content-Disposition: form-data; name=\"image\"; filename=\"example.jpg\"" + lineBreak +
            "Content-Type: image/jpeg" + lineBreak + lineBreak +
            new String(imageBytes) + lineBreak +
            "--" + boundary + lineBreak +
            "Content-Disposition: form-data; name=\"profile\"" + lineBreak + lineBreak +
            profileData + lineBreak +
            "--" + boundary + "--" + lineBreak;

    HttpRequest request = HttpRequest.newBuilder()
        .uri(URI.create(serverUrl))
        .header("Content-Type", "multipart/form-data; boundary=" + boundary)
        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
        .build();

    long start = System.currentTimeMillis();
    HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
    long latency = System.currentTimeMillis() - start;

    synchronized (postLatencies) {
      postLatencies.add(latency);
    }
    logLatency(start, "POST", latency, response.statusCode());
  }

  private static void sendGetRequest(HttpClient client, String serverUrl) throws IOException, InterruptedException {
    HttpRequest request = HttpRequest.newBuilder()
        .uri(URI.create(serverUrl))
        .GET()
        .build();

    long start = System.currentTimeMillis();
    HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
    long latency = System.currentTimeMillis() - start;

    synchronized (getLatencies) {
      getLatencies.add(latency);
    }
    logLatency(start, "GET", latency, response.statusCode());
  }

  private static void logLatency(long startTime, String requestType, long latency, int responseCode) {
    try (FileWriter writer = new FileWriter(CSV_FILE, true)) {
      writer.append(startTime + "," + requestType + "," + latency + "," + responseCode + "\n");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private static void computeStatistics() {
    System.out.println("POST Request Stats:");
    printStats(postLatencies);
    System.out.println("GET Request Stats:");
    printStats(getLatencies);
  }

  private static void printStats(List<Long> latencies) {
    if (latencies.isEmpty()) {
      System.out.println("No data available.");
      return;
    }

    Collections.sort(latencies);
    long min = latencies.get(0);
    long max = latencies.get(latencies.size() - 1);
    double mean = latencies.stream().mapToLong(Long::longValue).average().orElse(0.0);
    long median = latencies.get(latencies.size() / 2);
    long p99 = latencies.get((int) (latencies.size() * 0.99));

    System.out.println("Min: " + min + " ms");
    System.out.println("Max: " + max + " ms");
    System.out.println("Mean: " + mean + " ms");
    System.out.println("Median: " + median + " ms");
    System.out.println("99th Percentile (P99): " + p99 + " ms");
  }
}
